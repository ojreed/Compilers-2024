This directory is for low-level (x86-64) code generation
and optimization.
