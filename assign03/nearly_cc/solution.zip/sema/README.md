This directory is for files related to semantic analysis:
SemanticAnalysis, Type, Symbol, SymbolTable, etc.
