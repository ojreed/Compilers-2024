This directory is for the AST representation and friends:
NodeBase, Node, Location, etc.
