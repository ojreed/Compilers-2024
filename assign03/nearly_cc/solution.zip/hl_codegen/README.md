This directory is for high-level code generation and optimization.
