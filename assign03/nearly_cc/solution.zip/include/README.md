All non-automatically-generated header files go in this directory.
